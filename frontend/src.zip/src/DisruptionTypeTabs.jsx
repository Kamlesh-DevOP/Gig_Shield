import { CloudRain, Zap, Fuel, Wifi, Users, AlertTriangle, ChevronRight, Clock } from "lucide-react";

// ─── DISRUPTION TYPE SELECTOR ─────────────────────────────────────────────────
// Extended scenario picker for SimulationPage showing all 3 disruption categories.
// Usage: <DisruptionTypeTabs scenario={scenario} setScenario={fn} isRunning={bool} />

const CATEGORIES = [
    {
        id: "weather",
        label: "Weather Events",
        icon: CloudRain,
        color: "#2563EB",
        types: [
            { key: "flood", label: "Heavy Rainfall / Flood", desc: "150–250mm rain in 24h", live: true },
            { key: "cyclone", label: "Cyclone Alert", desc: "200–300mm + high winds", live: true },
            { key: "normal", label: "Normal Conditions", desc: "0–120mm random rain", live: true },
        ],
    },
    {
        id: "societal",
        label: "Societal Disruptions",
        icon: Users,
        color: "#D97706",
        types: [
            { key: "strike", label: "Transport Strike", desc: "Metro/bus halt, logistics freeze", live: false },
            { key: "curfew", label: "Government Curfew", desc: "Operational ban on movement", live: false },
            { key: "protest", label: "Civil Protest / Rally", desc: "Route blockages, zone lockdown", live: false },
        ],
    },
    {
        id: "technical",
        label: "Technical Failures",
        icon: Wifi,
        color: "#7C3AED",
        types: [
            { key: "platform_down", label: "Platform Outage", desc: "App server crash / API failure", live: false },
            { key: "fuel_shortage", label: "Fuel Shortage", desc: "Petrol unavailable, depot halt", live: false },
            { key: "isp_blackout", label: "ISP Blackout", desc: "Network / internet outage", live: false },
        ],
    },
];

export default function DisruptionTypeTabs({ scenario, setScenario, isRunning }) {
    // Derive category from scenario
    const activeCat = CATEGORIES.find(c => c.types.some(t => t.key === scenario))?.id || "weather";

    return (
        <div style={{ marginBottom: 16 }}>
            {/* Category row */}
            <div style={{ display: "flex", gap: 8, marginBottom: 10, flexWrap: "wrap" }}>
                {CATEGORIES.map(cat => {
                    const Icon = cat.icon;
                    const isActive = activeCat === cat.id;
                    return (
                        <button
                            key={cat.id}
                            disabled={isRunning || cat.id !== "weather"}
                            style={{
                                display: "flex", alignItems: "center", gap: 7,
                                padding: "7px 14px",
                                background: isActive ? cat.color + "12" : "var(--surface)",
                                border: `1.5px solid ${isActive ? cat.color : "var(--border)"}`,
                                borderRadius: 9, cursor: cat.id === "weather" ? "pointer" : "not-allowed",
                                fontFamily: "var(--font)", fontWeight: 600, fontSize: 12,
                                color: isActive ? cat.color : "var(--muted)",
                                opacity: cat.id !== "weather" ? 0.7 : 1,
                                transition: "all 0.18s",
                            }}
                        >
                            <Icon size={13} color={isActive ? cat.color : "var(--muted)"} />
                            {cat.label}
                            {cat.id !== "weather" && (
                                <span style={{
                                    fontSize: 9, fontWeight: 700, padding: "1px 6px",
                                    borderRadius: 20, background: "rgba(100,100,100,0.1)",
                                    color: "var(--muted)", letterSpacing: 0.5,
                                }}>
                                    SOON
                                </span>
                            )}
                        </button>
                    );
                })}
            </div>

            {/* Type buttons for active category */}
            {CATEGORIES.filter(c => c.id === activeCat).map(cat => (
                <div key={cat.id} style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                    {cat.types.map(t => (
                        <button
                            key={t.key}
                            className={`sim-scenario-btn ${scenario === t.key ? "active" : ""}`}
                            onClick={() => t.live && !isRunning && setScenario(t.key)}
                            disabled={isRunning || !t.live}
                            style={{ minWidth: 170, opacity: t.live ? 1 : 0.6, cursor: t.live ? "pointer" : "not-allowed" }}
                        >
                            <span className="ssb-label">
                                {t.label}
                                {!t.live && (
                                    <span style={{
                                        marginLeft: 6, fontSize: 9, fontWeight: 700, padding: "1px 6px",
                                        borderRadius: 20, background: "rgba(100,100,100,0.1)",
                                        color: "var(--muted)", letterSpacing: 0.5, verticalAlign: "middle",
                                    }}>
                                        COMING SOON
                                    </span>
                                )}
                            </span>
                            <span className="ssb-desc">{t.desc}</span>
                        </button>
                    ))}
                </div>
            ))}

            {/* Non-weather note */}
            {activeCat !== "weather" && (
                <div style={{
                    marginTop: 10, padding: "10px 14px",
                    background: "rgba(217,119,6,0.06)", border: "1px solid rgba(217,119,6,0.2)",
                    borderRadius: 9, fontSize: 12, color: "#92400E",
                    display: "flex", alignItems: "center", gap: 8,
                }}>
                    <Clock size={13} color="#D97706" />
                    Societal & technical disruption triggers are in development.
                    The parametric model is designed to handle these categories — backend pipeline integration coming next.
                </div>
            )}
        </div>
    );
}